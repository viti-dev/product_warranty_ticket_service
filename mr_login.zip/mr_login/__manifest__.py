{
    "name": "MR Login",
    "version": "1.0.0",
    "summary": "Philips MRI-styled login page overriding Odoo 18 web login",
    "category": "Web",
    "license": "LGPL-3",
    "author": "Laxman Kalewar",
    "depends": ["web"],
    "data": [
        "views/sign_up.xml"
    ],
    "assets": {
        "web.assets_backend": [
            'mr_login/static/src/css/header_color.css'
        ]
    },
    "installable": True,
    "application": False
}
